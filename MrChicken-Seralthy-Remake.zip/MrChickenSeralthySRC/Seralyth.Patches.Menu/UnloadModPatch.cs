using GorillaTagScripts.VirtualStumpCustomMaps;
using HarmonyLib;
using Seralyth.Mods.CustomMaps;

namespace Seralyth.Patches.Menu;

[HarmonyPatch(typeof(CustomMapManager), "UnloadMap")]
public class UnloadModPatch
{
	public static void Prefix(bool returnToSinglePlayerIfInPublic)
	{
		Manager.UpdateCustomMapsTab();
	}
}
